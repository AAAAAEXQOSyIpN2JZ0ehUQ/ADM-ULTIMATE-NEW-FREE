fail2ban.server.failmanager module
==================================

.. automodule:: fail2ban.server.failmanager
    :members:
    :undoc-members:
    :show-inheritance:
