#!/bin/bash

rm -rf $HOME/install_panelweb.sh
rm -rf $HOME/Panelweb.sh

wget https://raw.githubusercontent.com/AAAAAEXQOSyIpN2JZ0ehUQ/ADM-ULTIMATE-NEW-FREE/master/Install/Panel_Web/Panelweb.sh; chmod +x Panelweb.sh; ./Panelweb.sh