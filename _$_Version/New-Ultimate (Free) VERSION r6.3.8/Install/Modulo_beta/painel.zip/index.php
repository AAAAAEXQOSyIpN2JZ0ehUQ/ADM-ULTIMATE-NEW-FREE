<!DOCTYPE html>
<html>
<head>
	<!-- PRESERVE O ORIGINAL FOI FEITO COM CARINHO PENSANDO EM VOCE
		 TELEGRAM: t.me/digitandoo
		 DATA: 26/10/2017
		 =================================================================
		         +++++++++++++++++ ATENÇÃO +++++++++++++++++++++ 
		 NAO MECHA NA ONDE NAO SABE ESSE PAINE NAO TEM ASSISTENCIA
		 ELE FOI ENTREGUE A VOCE FUNCIONANDO PERFEITO ENTAO SE FOR ALTERAR
		 É BOM SABER AONDE TA MEXENDO 
		 ================================================================== 
	!-->
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <meta name="description" content="">
  <title>Pagina Inicial</title>
  <link rel="stylesheet" href="assets/tether/tether.min.css">
  <link rel="stylesheet" href="assets/bootstrap/css/bootstrap.min.css">
  <link rel="stylesheet" href="assets/bootstrap/css/bootstrap-grid.min.css">
  <link rel="stylesheet" href="assets/bootstrap/css/bootstrap-reboot.min.css">
  <link rel="stylesheet" href="assets/socicon/css/styles.css">
  <link rel="stylesheet" href="assets/theme/css/style.css">
  <link rel="stylesheet" href="assets/mobirise/css/mbr-additional.css" type="text/css">
</head>
<body>
<section class="header1 cid-qz5mmoADxE mbr-parallax-background" id="header1-h" data-rv-view="114">

<div class="container">
        <div class="row justify-content-md-center">
            <div class="mbr-white col-md-10">
                <h1 class="mbr-section-title align-center mbr-bold pb-3 mbr-fonts-style display-1">ADM.PRO <em>ULTIMATE</em></h1>
                <h3 class="mbr-section-subtitle align-center mbr-light pb-3 mbr-fonts-style display-2">Bem Vindo | Area de download</h3>
                <p class="mbr-text align-center pb-3 mbr-fonts-style display-5">Entre no nosso canal e grupo no telegram e fique por dentro das novidades</p>
                <div class="mbr-section-btn align-center"><a class="btn btn-md btn-primary display-4" href="https://t.me/joinchat/Dmxs4UARe4-XQ4BTlu1BQw"><span class="socicon socicon-telegram mbr-iconfont mbr-iconfont-btn"></span>GRUPO OFICIAL</a>
                    <a class="btn btn-md btn-primary display-4" href="https://t.me/admmanager"><span class="socicon socicon-telegram mbr-iconfont mbr-iconfont-btn"></span>CANAL OFICIAL</a></div>
            </div>
        </div>
    </div>

</section>

<section class="features3 cid-qz5p0sOupq" id="features3-j" data-rv-view="117">
<div class="container">
        <div class="media-container-row">
            <div class="card p-3 col-12 col-md-6 col-lg-3">
                <div class="card-wrapper">
                    <div class="card-img">
                        <img src="assets/images/vivo-icon-png-9-300x300.jpg" title="" media-simple="true">
                    </div>
                    <div class="card-box">
                        <h4 class="card-title mbr-fonts-style display-7">ARQUIVO | OP VIVO</h4>
                        <p class="mbr-text mbr-fonts-style display-7">
                            Baixe o melhor arquivo para o aplicativo HTTP INJETOR.
						<br>Após baixar importe o arquivo pelo apicativo coloque o usuario e senha e aperte INICIAR</p>
                    </div>
                    <div class="mbr-section-btn text-center"><a href="adm/arquivos/vivo.ehi" class="btn btn-primary display-4">DOWNLOAD</a></div>
                </div>
            </div>

            <div class="card p-3 col-12 col-md-6 col-lg-3">
                <div class="card-wrapper">
                    <div class="card-img">
                        <img src="assets/images/claro-logo-3-2000x2000.jpg" title="" media-simple="true">
                    </div>
                    <div class="card-box">
                        <h4 class="card-title mbr-fonts-style display-7">ARQUIVO | OP CLARO</h4>
                        <p class="mbr-text mbr-fonts-style display-7">
                            Baixe o melhor arquivo para o aplicativo HTTP INJETOR.
						<br>Após baixar importe o arquivo pelo apicativo coloque o usuario e senha e aperte INICIAR</p>
                    </div>
                    <div class="mbr-section-btn text-center"><a href="adm/arquivos/claro.ehi" class="btn btn-primary display-4">DOWNLOAD</a></div>
                </div>
            </div>

            <div class="card p-3 col-12 col-md-6 col-lg-3">
                <div class="card-wrapper">
                    <div class="card-img">
                        <img src="assets/images/logotipo-da-oi-500x436.jpg" title="" media-simple="true">
                    </div>
                    <div class="card-box">
                        <h4 class="card-title mbr-fonts-style display-7"><br><br>ARQUIVO | OP OI</h4>
                        <p class="mbr-text mbr-fonts-style display-7">
                           Baixe o melhor arquivo para o aplicativo HTTP INJETOR.
						<br>Após baixar importe o arquivo pelo apicativo coloque o usuario e senha e aperte INICIAR</p>
                    </div>
                    <div class="mbr-section-btn text-center"><a href="adm/arquivos/oi.ehi" class="btn btn-primary display-4">DOWNLOAD</a></div>
                </div>
            </div>

            <div class="card p-3 col-12 col-md-6 col-lg-3">
                <div class="card-wrapper">
                    <div class="card-img">
                        <img src="assets/images/download-225x225.jpg" title="" media-simple="true">
                    </div>
                    <div class="card-box">
                        <h4 class="card-title mbr-fonts-style display-7">APP | HTTP INJETOR<br></h4>
                        <p class="mbr-text mbr-fonts-style display-7">
                           Download diretamente da playstore.
					   <br>Assim mantem voçês sempre atualizado.
                       <br><br><br></p>
                    </div>
                    <div class="mbr-section-btn text-center"><a href="https://play.google.com/store/apps/details?id=com.evozi.injector" class="btn btn-primary display-4">DOWNLOAD</a></div>
                </div>
            </div>
        </div>
    </div>
</section>
  <script src="assets/web/assets/jquery/jquery.min.js"></script>
  <script src="assets/popper/popper.min.js"></script>
  <script src="assets/tether/tether.min.js"></script>
  <script src="assets/bootstrap/js/bootstrap.min.js"></script>
  <script src="assets/smooth-scroll/smooth-scroll.js"></script>
  <script src="assets/jarallax/jarallax.min.js"></script>
  <script src="assets/theme/js/script.js"></script>
  </body>
</html>