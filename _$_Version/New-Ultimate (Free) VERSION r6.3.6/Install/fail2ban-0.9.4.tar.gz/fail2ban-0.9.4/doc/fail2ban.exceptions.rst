fail2ban.exceptions module
==========================

.. automodule:: fail2ban.exceptions
    :members:
    :undoc-members:
    :show-inheritance:
